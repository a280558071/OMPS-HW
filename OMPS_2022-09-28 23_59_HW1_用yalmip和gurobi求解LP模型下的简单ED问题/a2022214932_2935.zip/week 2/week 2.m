%matlab+gurobi
%设置实数型变量，2x1
x = sdpvar(2,1);

%设定目标函数
z = 60*x(1)+20*x(2);

%设定限制条件
cons=[x(1)+2*x(2)<=40,4*x(1)+3*x(2)<=120,x(1)>=0,x(2)>=0];

%选择优化器
ops = sdpsettings('solver','gurobi');

%求解
sol=optimize(cons,-z,ops);

%显示x1，x2，z的值
s1=value(x)
s2=value(z)

%绘制出可行域图
plot(cons);
axis([0,60,0,50]);
title('可行域');
xlabel('MWh');
ylabel('$');

