from scipy import optimize
import numpy as np

c = np.array([60, 20])
A = np.array([[1,2],[4,3]])
b = np.array([40, 120])
x1 = (0, None)
x2 = (0, None)
x3 = (0, None)

res = optimize.linprog(-c, A, b,bounds=(x1, x2))
print(res)