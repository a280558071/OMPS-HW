u=sdpvar(2,1);
A=[40 120];
w=A*u;
B=[1 4;2 3],C=[40;50];
Cons=[B*u>=C,u(1)>=0,u(2)>=0,u(1)<=10000000000000,u(2)<=100000000000000];
ops=sdpsettings('solver','gurobi');
sol=optimize(Cons,w,ops);
s_u=value(u),s_w=value(w)
plot(Cons);
axis([0,60,0,50]);
