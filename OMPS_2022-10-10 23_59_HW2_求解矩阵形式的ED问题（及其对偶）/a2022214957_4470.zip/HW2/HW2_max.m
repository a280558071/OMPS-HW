x=sdpvar(2,1);
A=[40 50];
z=A*x;
B=[1 2;4 3;1 1;-1 -1],C=[40;120;30;-30];
Cons=[B*x<=C,x(1)>=0,x(2)>=0];
ops=sdpsettings('solver','gurobi');
sol=optimize(Cons,-z,ops);
s_x=value(x),s_z=value(z)
plot(Cons);
axis([0,60,0,50]);