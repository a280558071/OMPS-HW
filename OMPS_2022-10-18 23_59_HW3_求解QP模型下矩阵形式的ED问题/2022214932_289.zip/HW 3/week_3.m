%原问题求解
clc;clear;
close all;
x = sdpvar(2,1);
P1 = [4,0;0,6];
Q1 = [40,50]';
A1 = [1,2;4,3;-1,0;0,-1;1,1];
B1 = [40;120;0;0;30];
Cons1 = [A1(1:4,:)*x <= B1(1:4,:),A1(5,:)*x == B1(5,:)];
ops = sdpsettings('verbose',0,'solver','gurobi');
z1 = (1/2)*(x')*P1*x+(Q1')*x;
result1 = optimize(Cons1,z1,ops);
if result1.problem == 0
    value(x)
    value(z1)
else
    disp('error');
end
%F0梯度
%F0 = @(y) 2*y(1)^2+40*y(1)+3*y(2)^2+50*y(2);
F0 = @(y) (1/2)*([y(1),y(2)])*P1*[y(1),y(2)]'+(Q1')*[y(1),y(2)]';
GF0 = computeNumericGradient(F0,[value(x(1)),value(x(2))]')
%Fi梯度
Fi = @(y) A1(1:4,:)*[y(1),y(2)]';
GFi =[];
for i=1:4
    Fi = @(y) A1(i,:)*[y(1),y(2)]';
    N  = computeNumericGradient(Fi,[value(x(1)),value(x(2))]');
        for j=1:2
            GFi(i,j) = N(:,j);
        end
end
GFi
%求解矩阵梯度
% Fi = A1(1:4,:);
% [GFiX,GFiY] = gradient(Fi)
% Hi梯度
Hi= @(y) A1(5,:)*[y(1),y(2)]';
GHi  = computeNumericGradient(Hi,[value(x(1)),value(x(2))]')
%求解矩阵梯度
%Hi= A1(5,:);
%GHi = gradient(Hi)
%对偶问题求解
%利用dual函数求解对偶问题
u1 = dual(Cons1(1))
u2 = dual(Cons1(2))
