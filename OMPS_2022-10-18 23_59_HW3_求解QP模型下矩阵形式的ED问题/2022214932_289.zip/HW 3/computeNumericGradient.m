function numgrad = computeNumericGradient(J, theta)
epsilon = 1e-4;
n = size(theta, 1);
numgrad = zeros(n, 1);
for i = 1:n,
    tmp1 = theta;
    tmp2 = theta;
    tmp1(i) = tmp1(i) + epsilon;
    tmp2(i) = tmp2(i) - epsilon;
    numgrad(i) = (J(tmp1) - J(tmp2))/2/epsilon;
end
numgrad = numgrad';